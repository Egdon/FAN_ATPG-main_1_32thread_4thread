# Include

This folder will store the the `.h` (header files) in the `pkg/` folder after compilation.

Each of the folders under `include/` corresponds to the folders in `pkg/`.

Now we have `common/`, `core/`, `fan/` and `interface/`.