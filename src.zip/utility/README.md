# Utility

This folder contains `.py` files that support useful utilities for this project.

    .
    |
    `--. patConvert/
       |
       |-- pat2stil.py    # Convert test pattern file from .pat to STIL format.
       |
       `-- stil2pat.py    # Convert test pattern file from STIL to .pat format.